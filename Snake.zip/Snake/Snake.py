import tkinter
import random

ROWS = 25
COLS = 25
TILE_SIZE=25

WINDOW_WIDTH = COLS * TILE_SIZE
WINDOW_HEIGHT = ROWS * TILE_SIZE

class Tile:
    def __init__(self, row, col):
        self.x = row
        self.y = col

#fenetre de jeu
window = tkinter.Tk()
window.title("Nuit de folies - Snake")
window.resizable(False, False)
canvas = tkinter.Canvas(window, width=WINDOW_WIDTH, height=WINDOW_HEIGHT, bg="dark gray", borderwidth=1, highlightthickness=1, highlightbackground="dark red")
canvas.pack()
window.update()

#centrer la fenetre
window.geometry(f"{WINDOW_WIDTH}x{WINDOW_HEIGHT}+{(window.winfo_screenwidth() // 2) - (WINDOW_WIDTH // 2)}+{(window.winfo_screenheight() // 2) - (WINDOW_HEIGHT // 2)}")

#initialisation du jeu
snake=Tile(5*TILE_SIZE, 5*TILE_SIZE)
food=Tile(random.randint(0, COLS-1)*TILE_SIZE, random.randint(0, ROWS-1)*TILE_SIZE)
snake_body = []
velocity_x=0
velocity_y=0
game_over=False
score=0
def change_direction(event):
    global velocity_x, velocity_y
    if (game_over):
        return
    if event.keysym == "z" and velocity_y != 1:
        velocity_x = 0
        velocity_y = -1
    elif event.keysym == "s" and velocity_y != -1:
        velocity_x = 0
        velocity_y = 1
    elif event.keysym == "q" and velocity_x != 1:
        velocity_x = -1
        velocity_y = 0
    elif event.keysym == "d" and velocity_x != -1:
        velocity_x = 1
        velocity_y = 0
    elif event.keysym == "Up" and velocity_y != 1:
        velocity_x = 0
        velocity_y = -1
    elif event.keysym == "Down" and velocity_y != -1:
        velocity_x = 0
        velocity_y = 1
    elif event.keysym == "Left" and velocity_x != 1:
        velocity_x = -1
        velocity_y = 0
    elif event.keysym == "Right" and velocity_x != -1:
        velocity_x = 1
        velocity_y = 0
def move():
    global snake, food, snake_body, game_over, score
    if (game_over):
        return
    if (snake.x < 0 or snake.x >= WINDOW_WIDTH or snake.y < 0 or snake.y >= WINDOW_HEIGHT):
        game_over = True
        return
    for tile in snake_body:
        if (snake.x == tile.x) and (snake.y == tile.y):
            game_over = True
            return
    if (snake.x == food.x) and (snake.y == food.y):
        snake_body.append(Tile(food.x, food.y))
        food.x = random.randint(0, COLS-1)*TILE_SIZE
        food.y = random.randint(0, ROWS-1)*TILE_SIZE 
        score += 1 
    for i in range(len(snake_body)-1, -1, -1):
        tile = snake_body[i]
        if (i==0):
            tile.x = snake.x
            tile.y = snake.y
        else:
            prev_tile = snake_body[i-1]
            tile.x = prev_tile.x
            tile.y = prev_tile.y


    snake.x += velocity_x * TILE_SIZE
    snake.y += velocity_y * TILE_SIZE
def color_random():
    r = lambda: random.randint(0,255)
    return f'#{r():02x}{r():02x}{r():02x}'

def draw():
    global snake, food, snake_body, score, game_over
    move()
    canvas.delete("all")
    canvas.create_rectangle(snake.x, snake.y, snake.x + TILE_SIZE, snake.y + TILE_SIZE, fill="aqua")
    canvas.create_oval(food.x, food.y, food.x + TILE_SIZE, food.y + TILE_SIZE, fill=color_random())
    for tile in snake_body:
        canvas.create_rectangle(tile.x, tile.y, tile.x + TILE_SIZE, tile.y + TILE_SIZE, fill=color_random())
    window.after(100, draw)
    if(game_over):
        canvas.create_text(WINDOW_WIDTH//2, WINDOW_HEIGHT//2, fill="black", font="Arial 30 bold", text=f"Rip Bozo t'as perdu ! \n Score: {score}! Pas dégueu hein?")
    else:
        canvas.create_text(50, 10, fill="black", font="Arial 15 bold", text=f"Score: {score}")
draw()
window.bind("<KeyRelease>", change_direction)
window.mainloop()